<template>
  <div class="message" v-if="message">
      <p>{{message}}</p>
  </div>
</template>

<script>
export default {
  props: {
    message: {
      type: String,
      required: true
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.message {
  text-align: center;
  padding: 20px;
  p {
    color: #d12828
  }
}

</style>
