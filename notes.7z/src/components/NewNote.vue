<template>
    <div class="new-note">
        <label for="">Title</label>
        <input type="text" v-model="note.title">
        <label for="">Description</label>
        <textarea v-model="note.descr"></textarea>
        <div class="block-note">
            <div class="block-priority" v-for="item in notePriority" :key="item.id">
            <label >{{item.label}}
            <input type="radio" class="note-priority" name="prioriry" :value="item.value" v-model="note.priority"></label>
        </div>
        </div>
        <button class="btn btnPrimary" @click="addNote">new note</button>
    </div>
</template>

<script>
export default {
    data() {
        return {
            notePriority: [
                {
                    id: 1,
                    label: 'Normal',
                    value: 0
                },
                {
                    id: 2,
                    label: 'Important',
                    value: 10
                },
                {
                    id: 3,
                    label: 'Critical',
                    value: 20
                }
            ]
        }
    },
    props: {
        note: {
            type: Object,
            required: true
        }
    },
    methods: {
        addNote() {
            this.$emit('addNote', this.note)
        }
    }
}
</script>

<style lang="scss" scoped>
.new-note {
    text-align: center;
    .btn {
        margin-top: 20px;
        margin-bottom: 20px;
    }
    .note-priority {
        margin: 10px 0;
        height: 30px;
    }
    .block-note {
        margin-top: 10px;
        display: flex;
        justify-content: space-around;
        align-items: center;
    }
}
</style>
